package modelo;

import modelo.actividades.Actividad;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Clase asociativa entre modelo.actividades.Actividad y Estudiantes.
 * La inscripción existe porque un estudiante se inscribe a una actividad concreta.
 * Debe notarse que esta relación tiene atributos propios que no pertenecen ni a la actividad ni al estudiante,
 * por eso es necesario modelarla como una clase independiente.
 */
public class Inscripcion implements Serializable {
    private Actividad actividad;
    private Estudiante estudiante;
    private LocalDate fecha;
    private String estado;

    /**
     * Ticket de acceso generado al confirmar la inscripción.
     * Se modela como un atributo de la inscripción porque cada inscripción puede tener un ticket asociado.
     */
    private TicketDeAcceso ticket;

    public Inscripcion(Actividad actividad, Estudiante estudiante, LocalDate fecha, String estado) {
        this.actividad = actividad;
        this.estudiante = estudiante;
        this.fecha = fecha;
        this.estado = estado;
    }

    public Actividad getActividad() {
        return actividad;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void confirmar()    {
        this.estado = "CONFIRMADA";
        this.ticket = new TicketDeAcceso();
    }

    public TicketDeAcceso getTicket() {
        return ticket;
    }

    /**
     * Clase anidada miembro que representa el ticket generado para una inscripción.
     * Se modela como una clase anidada porque el ticket solo tiene sentido en el contexto de una inscripción concreta
     * y necesita acceder a los datos de esa inscripción.
     */
    public final class TicketDeAcceso implements Serializable {
        private String idTicket;
        private LocalDate fechaEmision;

        public TicketDeAcceso() {
            this.idTicket = "TICKET-" + actividad.getId() + "-" + estudiante.getLegajo() + "-" + System.currentTimeMillis();
            this.fechaEmision = LocalDate.now();
            System.out.println("Ticket generado para la inscripción: " + idTicket);
        }

        public void enviarTicket() {
            System.out.println("Enviando ticket " + idTicket + " al estudiante " + estudiante.getNombre() + " para la actividad " + actividad.getTitulo());
        }
    }
}
